#Author: Rushika Karnati

def string_op():
    try:
        inp_a = str(input("Enter your string here:"))
        if inp_a != '' and inp_a is not None and inp_a.isspace() != True and inp_a.isnumeric() != True:

            output = inp_a[:-2]
            output = output[::-1] #reversal of the string after deleting 2  characters
            print(output)
            #end of block1
        else:
            print("please enter a valid string")
    except Exception as error:
        print("Error occured {}".format(error))
        # taking 2 numbers from the user and applying 4 arithmetic operations
           #start of block2
    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))

    print("Addition:", num1 + num2)
    print("Subtraction:", num1 - num2)
    print("Multiplication:", num1 * num2)

    if num2 != 0:
        print("Division:", num1 / num2)
    else:
        print("Cannot divide by zero.")
#end of block2
if __name__ == "__main__":
    string_op()